﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace ExcelReader
{
    public partial class mainForm : Form
    {
        public string[] workSheetNames = new string[] { };   //List of Worksheet names 
        private string fileName;  //Path and file name of the Excel Workbook
        private string connectionString;

        public mainForm()
        {
            InitializeComponent();
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog(this) == DialogResult.Cancel)
                return;

            fileName = openFileDialog.FileName;

            //split the text into an array using '.', this will put the
            //file extension in the last element of the array
            string[] splitByDots = fileName.Split(new char[1] { '.' });

            //Excel 97-2003 file
            if (splitByDots[splitByDots.Length - 1] == "xls")
                OpenExcelFile(false);

            //Excel 2007 file
            if (splitByDots[splitByDots.Length - 1] == "xlsx")
                OpenExcelFile(true);

            //load the sheet names in the ComboBox
            sheetsToolStripComboBox.Items.Clear();
            foreach (string sheetName in workSheetNames)
            {
                sheetsToolStripComboBox.Items.Add(sheetName);
            }

            //select the first sheet in the file
            sheetsToolStripComboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// Open the Excel Workbook
        /// </summary>
        /// <param name="isOpenXMLFormat">Is the file Open XML Format (Excel 2007)</param>
        public void OpenExcelFile(bool isOpenXMLFormat)
        {
            //open the excel file using OLEDB
            OleDbConnection con;

            if (isOpenXMLFormat)
                //read a 2007 file
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" +
                    fileName + ";Extended Properties=\"Excel 8.0;HDR=YES;\"";
            else
                //read a 97-2003 file
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
                    fileName + ";Extended Properties=Excel 8.0;";

            con = new OleDbConnection(connectionString);
            con.Open();

            //get all the available sheets
            System.Data.DataTable dataSet = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            //get the number of sheets in the file
            workSheetNames = new String[dataSet.Rows.Count];
            int i = 0;
            foreach (DataRow row in dataSet.Rows)
            {
                //insert the sheet's name in the current element of the array
                //and remove the $ sign at the end
                workSheetNames[i] = row["TABLE_NAME"].ToString().Trim(new[] { '$' });
                i++;
            }

            if (con != null)
            {
                con.Close();
                con.Dispose();
            }

            if (dataSet != null)
                dataSet.Dispose();
        }

        /// <summary>
        /// Returns the contents of the sheet
        /// </summary>
        /// <param name="worksheetName">The sheet's name in a string</param>
        /// <returns>A DataTable containing the data</returns>
        public System.Data.DataTable GetWorksheet(string worksheetName)
        {
            OleDbConnection con = new System.Data.OleDb.OleDbConnection(connectionString);
            OleDbDataAdapter cmd = new System.Data.OleDb.OleDbDataAdapter(
                "select * from [" + worksheetName + "$]", con);

            con.Open();
            System.Data.DataSet excelDataSet = new DataSet();
            cmd.Fill(excelDataSet);
            con.Close();

            return excelDataSet.Tables[0];
        }

        private void sheetsToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //make sure something is selected
            if (sheetsToolStripComboBox.SelectedItem == null)
                return;

            //get the contents of the selected sheet in a DataTable
            DataTable sheetContents = GetWorksheet(sheetsToolStripComboBox.SelectedItem.ToString());
            
            //bind the GridView to the DataTable
            sheetDataGridView.DataSource = sheetContents;

            //resize all columns' widths to fit the data
            for (int i = 0; i < sheetDataGridView.Columns.Count; i++)
            {
                sheetDataGridView.AutoResizeColumn(i, DataGridViewAutoSizeColumnMode.AllCells);
            }

        }

    }
}
